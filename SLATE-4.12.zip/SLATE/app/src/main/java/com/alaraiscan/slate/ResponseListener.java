package com.alaraiscan.slate;

public interface ResponseListener {
    void onResponseChanged(String text);
}
